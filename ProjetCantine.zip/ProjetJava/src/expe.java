import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class expe extends JFrame {
	
	//CTRL + SHIFT + O pour g�n�rer les imports
	BDD MaBDD = new BDD();
	Object[][] data ;
	JPanel bilanPanel = new JPanel();
	
	  public expe(String date2){
		  
	    this.setLocationRelativeTo(null);
	    this.setTitle("JTable");
	    this.setSize(700, 220);
	    
	    data = MaBDD.select(date2);
	  

	    //Les titres des colonnes
	    String  title[] = {"nombre", "Etud","Dix","Navigo","PleinTarif","film","date"};
	    JTable tableau = new JTable(data, title);
	    //Nous ajoutons notre tableau � notre contentPane dans un scroll
	    //Sinon les titres des colonnes ne s'afficheront pas !
	    bilanPanel.add(tableau);
	    this.getContentPane().add(new JScrollPane(tableau));
	    
	  }   
	  

}