package Page;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Spinner;

public class Info {

	protected Shell shlJunior;
	private Text text;
	private Text text_1;
	
	
	int check = 0;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Info window = new Info();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlJunior.open();
		shlJunior.layout();
		while (!shlJunior.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlJunior = new Shell();
		shlJunior.setSize(818, 558);
		shlJunior.setText("Junior");
		
		Label lblUser = new Label(shlJunior, SWT.NONE);
		lblUser.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD | SWT.ITALIC));
		lblUser.setText("User");
		lblUser.setBounds(130, 27, 38, 17);
		
	
		
		
		
		String Classe[] = {"3emeJ","3emeV","2ndSn","2ndTU","2ndMEI","1erSn","1erTU","1erMEI","TerSn","TerTU","TerMEI","1erSti2D","TerSti2D","1erBtsSlam","2emeBtsSlam","1erBtsSISR"};  
		Combo combo = new Combo(shlJunior, SWT.DROP_DOWN | SWT.READ_ONLY);

		combo.setItems(Classe);
		combo.setBounds(99, 79, 134, 28);
		
		Button btnOrdreAlphabtique = new Button(shlJunior, SWT.CHECK);
		btnOrdreAlphabtique.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				  if(btnOrdreAlphabtique.getSelection( ))
		          {    
		              check = 1; 
		          }
		          else
		          {
		        	  check = 0; 
		          } 
			}
		});
		btnOrdreAlphabtique.setBounds(79, 118, 134, 23);
		btnOrdreAlphabtique.setText("Ordre Alphab\u00E9tique");
		
		Button btnNewButton = new Button(shlJunior, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
			}
		});
		
		
		btnNewButton.addListener(SWT.Selection, new Listener()
		{
			@Override
			public void handleEvent(Event arg0) {
				int idx = combo.getSelectionIndex();
				String choixClasse = combo.getItem(idx);
				
				  expe ChangeFen2 = new expe(choixClasse, check);
				  ChangeFen2.setVisible(true);
			}
		});
		
		btnNewButton.setBounds(94, 161, 105, 35);
		btnNewButton.setText("Voir Table");
		
		Label lblClasses = new Label(shlJunior, SWT.NONE);
		lblClasses.setBounds(56, 82, 42, 20);
		lblClasses.setText("Classe : ");
		
		Button btnNewButton_2 = new Button(shlJunior, SWT.NONE);
		btnNewButton_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		btnNewButton_2.setBounds(435, 248, 105, 35);
		btnNewButton_2.setText("Ajouter");
		
		Label label = new Label(shlJunior, SWT.SEPARATOR | SWT.VERTICAL);
		label.setBounds(277, 29, 2, 278);
		
		text = new Text(shlJunior, SWT.BORDER);
		text.setBounds(385, 79, 80, 31);
		
		text_1 = new Text(shlJunior, SWT.BORDER);
		text_1.setBounds(385, 134, 80, 31);
		
		Label lblAjoutUser = new Label(shlJunior, SWT.NONE);
		lblAjoutUser.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD | SWT.ITALIC));
		lblAjoutUser.setBounds(316, 26, 115, 25);
		lblAjoutUser.setText("Ajout User");
		
		Label lblLogin = new Label(shlJunior, SWT.NONE);
		lblLogin.setBounds(323, 82, 56, 25);
		lblLogin.setText("Nom");
		
		Label lblMdp = new Label(shlJunior, SWT.NONE);
		lblMdp.setBounds(315, 137, 70, 25);
		lblMdp.setText("Prenom");
		
		Label lblNewLabel = new Label(shlJunior, SWT.NONE);
		lblNewLabel.setText("Age");
		lblNewLabel.setBounds(341, 201, 38, 25);
		
		Label lblClasse = new Label(shlJunior, SWT.NONE);
		lblClasse.setBounds(495, 82, 63, 25);
		lblClasse.setText("Classe :");
		
		Combo combo_1 = new Combo(shlJunior, SWT.NONE);
		combo_1.setBounds(568, 79, 104, 33);
		
		Label lblRegime = new Label(shlJunior, SWT.NONE);
		lblRegime.setText("Regime : ");
		lblRegime.setBounds(495, 137, 70, 25);
		
		Combo combo_1_1 = new Combo(shlJunior, SWT.NONE);
		combo_1_1.setBounds(568, 134, 104, 33);
		
		Label label_1 = new Label(shlJunior, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_1.setBounds(94, 310, 446, 2);
		
		Label lblSupprimerUser = new Label(shlJunior, SWT.NONE);
		lblSupprimerUser.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD | SWT.ITALIC));
		lblSupprimerUser.setBounds(38, 343, 153, 28);
		lblSupprimerUser.setText("Supprimer User");
		
		Combo combo_2 = new Combo(shlJunior, SWT.NONE);
		combo_2.setBounds(109, 395, 104, 33);
		
		Label lblUser_1 = new Label(shlJunior, SWT.NONE);
		lblUser_1.setBounds(42, 398, 59, 25);
		lblUser_1.setText("User :");
		
		Label lblExterne = new Label(shlJunior, SWT.NONE);
		lblExterne.setText("Externe : ");
		lblExterne.setBounds(495, 199, 70, 25);
		
		Combo combo_1_1_1 = new Combo(shlJunior, SWT.NONE);
		combo_1_1_1.setBounds(568, 196, 104, 33);
		
		Button btnSupprimer = new Button(shlJunior, SWT.NONE);
		btnSupprimer.setText("Supprimer");
		btnSupprimer.setBounds(70, 445, 105, 35);
		

		Spinner spinner = new Spinner(shlJunior, SWT.BORDER);
		spinner.setMinimum(26);
		spinner.setBounds(385, 200, 72, 31);

	}
}
